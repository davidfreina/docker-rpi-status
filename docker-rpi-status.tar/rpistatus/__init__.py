from .cmd import vcgencmd, temperature, voltage, config, camera, clock, memory, ipaddress, hostname
